﻿
// CapturePacketDlg.cpp: 实现文件
//

#include "pch.h"
#include "framework.h"
#include "CapturePacket.h"
#include "CapturePacketDlg.h"
#include "afxdialogex.h"

using namespace std;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#define WM_PACKET WM_USER+1

pcap_pkthdr* pkt_header;
const u_char* pkt_data;
CString bar = _T("------------------------------------------------------\r\n");
CString arrow = _T(" --> ");

// #define _CRT_SECURE_NO_WARNINGS

// 用于应用程序“关于”菜单项的 CAboutDlg 对话框

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

	// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

// 实现
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CCapturePacketDlg 对话框



CCapturePacketDlg::CCapturePacketDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_CAPTUREPACKET_DIALOG, pParent)
	, m_IPaddress(0)
{
	

	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CCapturePacketDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_BUTTONCAPTURE, m_capture);
	DDX_Control(pDX, IDC_BUTTONRETURN, m_return);
	DDX_Control(pDX, IDC_BUTTONSTOPCAPTURE, m_stopCapture);
	DDX_Control(pDX, IDC_EDITFILTER, m_filter);
	/*DDX_Control(pDX, IDC_EDITINTERFACE, m_interface);
	DDX_Control(pDX, IDC_EDITINTERFACEINFO, m_interfaceInfo);*/
	DDX_Control(pDX, IDC_EDITLOG, m_log);
	DDX_Control(pDX, IDC_LISTINTERFACE, m_list_interface);
	DDX_Control(pDX, IDC_LISTINTERFACEINFO, m_list_interfaceInfo);
	//  DDX_Control(pDX, IDC_IPADDRESS, m_IPaddress);
	DDX_Control(pDX, IDC_BUTTONGETMAP, m_getMap);
	DDX_Control(pDX, IDC_EDITIPMACMAP, m_IP_MAC_Map);
	DDX_IPAddress(pDX, IDC_IPADDRESS, m_IPaddress);
}

BEGIN_MESSAGE_MAP(CCapturePacketDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTONCAPTURE, &CCapturePacketDlg::OnBnClickedButtoncapture)
	ON_LBN_SELCHANGE(IDC_LISTINTERFACE, &CCapturePacketDlg::OnSelchangeListinterface)

	// 进行消息映射
	ON_MESSAGE(WM_PACKET, OnPacket)

	ON_BN_CLICKED(IDC_BUTTONSTOPCAPTURE, &CCapturePacketDlg::OnBnClickedButtonstopcapture)
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDC_BUTTONRETURN, &CCapturePacketDlg::OnBnClickedButtonreturn)
	ON_BN_CLICKED(IDC_BUTTONGETMAP, &CCapturePacketDlg::OnBnClickedButtongetmap)
	ON_NOTIFY(IPN_FIELDCHANGED, IDC_IPADDRESS, &CCapturePacketDlg::OnFieldchangedIpaddress)
END_MESSAGE_MAP()


// CCapturePacketDlg 消息处理程序

BOOL CCapturePacketDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// 将“关于...”菜单项添加到系统菜单中。

	// IDM_ABOUTBOX 必须在系统命令范围内。
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != nullptr)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// 设置此对话框的图标。  当应用程序主窗口不是对话框时，框架将自动
	//  执行此操作
	SetIcon(m_hIcon, TRUE);			// 设置大图标
	SetIcon(m_hIcon, FALSE);		// 设置小图标

	// TODO: 在此添加额外的初始化代码
	// devMAC.insert(pair<CString, CString>(_T("192.168.1.161"), _T("50:2b:73:d5:50:ea")));

	int i = 0; // 标识找到 i 个设备

	/* Retrieve the device list */
	if (pcap_findalldevs_ex(PCAP_SRC_IF_STRING, NULL, &alldevs, errbuf) == -1)
	{
		fprintf(stderr, "Error in pcap_findalldevs: %s\n", errbuf);
		AfxMessageBox((CString)errbuf);
		exit(1);
	}

	/* Print the list */
	for (pcap_if_t* d = alldevs; d; d = d->next)
		m_list_interface.InsertString(-1, (CString)("%d. %s\r\n", ++i, d->name));
	UpdateData(true);
	Invalidate(true);
	UpdateWindow(); // 更新窗口

	if (i == 0) // 如果没有检测到设备
	{
		AfxMessageBox(_T("No interfaces found! Make sure Npcap is installed."));
		return -1;
	}


	m_list_interface.SetCurSel(0); // 默认选中第一行
	int cur = m_list_interface.GetCurSel(); // 获取listbox被选中的行的数目

	// 找到当前指向的设备
	curdev = alldevs;
	while (cur--)
		curdev = curdev->next;
	UpdateInfo();

	// 禁用“停止捕获”控件
	m_stopCapture.EnableWindow(false);

	return TRUE;  // 除非将焦点设置到控件，否则返回 TRUE
}

void CCapturePacketDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// 如果向对话框添加最小化按钮，则需要下面的代码
//  来绘制该图标。  对于使用文档/视图模型的 MFC 应用程序，
//  这将由框架自动完成。

void CCapturePacketDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // 用于绘制的设备上下文

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// 使图标在工作区矩形中居中
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// 绘制图标
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

//当用户拖动最小化窗口时系统调用此函数取得光标
//显示。
HCURSOR CCapturePacketDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CCapturePacketDlg::displayString(CEdit& editCtrl, CString& str)
{
	CString tmp;
	// tmp.Append(_T("\r\n"));
	editCtrl.GetWindowTextW(tmp);
	editCtrl.SetWindowTextW(tmp + str);
	/*UpdateData(true);
	Invalidate(true);
	UpdateWindow();*/
}

CString ConvertIP(DWORD ip)
{
	unsigned char a, b, c, d;
	a = ip & 0xFF;
	b = (ip >> 8) & 0xFF;
	c = (ip >> 16) & 0xFF;
	d = (ip >> 24) & 0xFF;

	CString conv;
	conv.Format(L"%u.%u.%u.%u", a, b, c, d);
	return conv;
}

CString ConvertInputIP(DWORD ip)
{
	unsigned char a, b, c, d;
	d = ip & 0xFF;
	c = (ip >> 8) & 0xFF;
	b = (ip >> 16) & 0xFF;
	a = (ip >> 24) & 0xFF;

	CString conv;
	conv.Format(L"%u.%u.%u.%u", a, b, c, d);
	return conv;
}

// 定义一个前十六位全为 0，后十六位全为 1 的常量
const DWORD overflowCrush = 0b00000000000000001111111111111111;
WORD CheckOverflow(DWORD& now)
{
	// 如果现在的数比 max(WORD) 大了，说明溢出了
	if (now > WORD_MAX)
	{
		// 回卷
		now = overflowCrush & now;
		now++;
	}
	return now;
}

WORD IpCheckSum(IPHeader_t IPHeader)
{
	// 考虑可能溢出，采用 DWORD 类型
	DWORD CheckSum, temp1, temp2;

	// 按照算法一步一步做
	temp1 = (IPHeader.TOS << 8) + IPHeader.Ver_HLen;
	temp2 = IPHeader.TotalLen;
	CheckSum = temp1 + temp2;
	CheckOverflow(CheckSum);

	temp1 = IPHeader.ID;
	temp2 = CheckSum;
	CheckSum = temp1 + temp2;
	CheckOverflow(CheckSum);

	temp1 = IPHeader.Flag_Segment;
	temp2 = CheckSum;
	CheckSum = temp1 + temp2;
	CheckOverflow(CheckSum);

	temp1 = (IPHeader.Protocol << 8) + IPHeader.TTL;
	temp2 = CheckSum;
	CheckSum = temp1 + temp2;
	CheckOverflow(CheckSum);

	// IP 数据报的头部校验和就不加了

	temp1 = IPHeader.SrcIP >> 16;
	temp2 = CheckSum;
	CheckSum = temp1 + temp2;
	CheckOverflow(CheckSum);

	temp1 = IPHeader.SrcIP & overflowCrush;
	temp2 = CheckSum;
	CheckSum = temp1 + temp2;
	CheckOverflow(CheckSum);

	temp1 = IPHeader.DstIP >> 16;
	temp2 = CheckSum;
	CheckSum = temp1 + temp2;
	CheckOverflow(CheckSum);

	temp1 = IPHeader.DstIP & overflowCrush;
	temp2 = CheckSum;
	CheckSum = temp1 + temp2;
	CheckOverflow(CheckSum);

	// 考虑可选和填充部分
	int HLen = IPHeader.Ver_HLen & 0x0f;
	int OptLen = HLen - 5;

	for (int i = 0; i < OptLen; ++i)
	{
		temp1 = IPHeader.Opt[i];
		temp2 = CheckSum;
		CheckSum = temp1 + temp2;
		CheckOverflow(CheckSum);
	}

	return (~((WORD)CheckSum));
}

// 消息处理函数
LRESULT CCapturePacketDlg::OnPacket(WPARAM wParam, LPARAM lParam)
{
	// 处理捕获到的数据包
	// IP 数据报部分
	if (m_capStatus == true)
	{
		Data_t* IPPacket;
		WORD RecvChecksum; // 头部校验和
		WORD Identifier; // 标识
		WORD CheckSum; // 计算出的头部校验和


		IPPacket = (Data_t*)pkt_data;
		WORD FrameType = (IPPacket->FrameHeader.FrameType);
		BYTE Ver_HLen = (IPPacket->IPHeader.Ver_HLen >> 4);



		// IPv6 没有头部校验和，下面是维基百科的说法
		// In order to increase performance, 
		// and since current link layer technology and transport or application layer protocols are assumed to provide sufficient error detection, 
		// the header has no checksum to protect it.

		if (FrameType == 8 && Ver_HLen == 4) // 保证是 IP 数据报，保证版本为 IPv4
		// if (FrameType == 2048) // 保证是 IP 数据报，保证版本正确
		{
			Identifier = IPPacket->IPHeader.ID;
			RecvChecksum = IPPacket->IPHeader.Checksum;
			CheckSum = IpCheckSum(IPPacket->IPHeader);

			// 下面是输出
			// 时间输出
			CString timeStr;
			timeStr.Format(_T(" %d "), pkt_header->ts.tv_sec);
			time_t t = pkt_header->ts.tv_sec;
			tm* timeptr = localtime(&t);
			char buffer[80];
			strftime(buffer, sizeof(buffer), "%Y/%m/%d %H:%M:%S", timeptr);
			timeStr.Format(_T("%s.%d"), (CString)buffer, pkt_header->ts.tv_usec);

			// IP 报文头长度输出
			CString len;
			// len.Format(_T(" len: %d  FrameType: %d\r\n"), pkt_header->caplen, FrameType);
			// len.Format(_T(" len: %d  Ver_HLen: %d\r\n"), pkt_header->caplen, Ver_HLen);
			len.Format(_T(" len: %d \r\n"), IPPacket->IPHeader.TotalLen);
			displayString(m_log, timeStr + len);

			// 标识：头部校验和：计算出的头部校验和：
			CString info;
			info.Format(_T("标识：%04x  头部校验和： %04x  计算出的头部校验和：%04x\r\n"),
				ntohs(Identifier), ntohs(RecvChecksum), ntohs(CheckSum));
			//info.Format(_T("标识：%04x  头部校验和： %04x  计算出的头部校验和：%04x\r\n"),
			//	(Identifier), (RecvChecksum), (CheckSum));
			displayString(m_log, info + bar);
		}
	}

	// ARP 报文部分
	if (m_arpCapStatus == true)
	{
		CString returnMAC; // ARP 帧回复的源 MAC 地址

		ARPFrame_t* ARPPacket;
		WORD Operation; //操作字段 1 -> ARP 请求, 2 -> ARP 回复
		BYTE SendHa[6];	//源 MAC 地址
		DWORD SendIP;	//源 IP 地址
		BYTE RecvHa[6];	//目的 MAC 地址
		DWORD RecvIP;	//目的 IP 地址

		ARPPacket = (ARPFrame_t*)pkt_data;
		Operation = ntohs(ARPPacket->Operation);
		SendIP = (ARPPacket->SendIP);
		RecvIP = (ARPPacket->RecvIP);

		// 输入的 IP
		CString inputIP = ConvertInputIP(m_IPaddress);

		// 转换成 CString 型 IP 地址，存入变量
		CString tempSendIP = ConvertIP(SendIP);

		// 转换成 CString 型 IP 地址，存入变量
		CString tempRecvIP = ConvertIP(RecvIP);

		if (Operation == 2) // 保证是 ARP 回复
		{
			map<CString, CString>::iterator it;
			it = devMAC.find(tempSendIP);

			sockaddr_in* temp;
			IN_ADDR temp1;
			char* temp_data;
			CString curdevIP; 
			// CString IP; // 存放 IP 的临时变量

			for (pcap_addr* a = curdev->addresses; a != NULL; a = a->next)
			{
				if (a->addr->sa_family == AF_INET) // 判断地址是否为 IP 地址
				{
					temp = (sockaddr_in*)(a->addr);
					temp1 = temp->sin_addr;
					temp_data = inet_ntoa(temp1); // inet_ntoa 函数转换网络字节排序的地址为标准的ASCII以点分开的地址,该函数返回指向点分开的字符串地址的指针
					curdevIP = CString(temp_data); // 获取 IP 地址
				}
			}

			// 一般情况(SendIP = 输入的 IP; RecvIP = 本机 IP)
			// 其他设备发出的，用于回应本机请求的回复
			if (tempSendIP == inputIP && tempRecvIP == curdevIP)
			{
				// m_gotARPreply = true; // 已捕获 ARP 回复
				
				for (int i = 0; i < 6; i++)
				{
					SendHa[i] = ARPPacket->SendHa[i];
					RecvHa[i] = ARPPacket->RecvHa[i];
				}

				returnMAC.Format(L"%02x:%02x:%02x:%02x:%02x:%02x\r\n", int(SendHa[0]), int(SendHa[1]), int(SendHa[2]), int(SendHa[3]), int(SendHa[4]), int(SendHa[5]));
				displayString(m_IP_MAC_Map, strIPaddress + arrow + returnMAC);
			}

			// SendIP == 本机 IP，RecvIP == 192.168.1.250
			// 本机发出的，用于回应假 IP(192.168.1.250)发出请求的回复
			else if (tempRecvIP == "192.168.1.250")
			{
				for (int i = 0; i < 6; i++)
				{
					SendHa[i] = ARPPacket->SendHa[i];
					RecvHa[i] = ARPPacket->RecvHa[i];
				}

				returnMAC.Format(L"%02x:%02x:%02x:%02x:%02x:%02x\r\n", int(SendHa[0]), int(SendHa[1]), int(SendHa[2]), int(SendHa[3]), int(SendHa[4]), int(SendHa[5]));
				devMAC.insert(pair<CString, CString>(tempSendIP, returnMAC)); // 插入映射表
			}

			// SendIP == 本机 IP，RecvIP == 其他 IP
			// 本机发出的，用于回应其他设备的请求的回复
			else 
			{
				// 这种情况下就啥也不干
			}
		}
	}

	return LRESULT();
}


// error C2440: “类型转换” : 无法从“overloaded-function”转换为 xxx
// 原因：线程函数需要静态成员函数或全局函数

UINT Capturer(PVOID hWnd) // 数据包捕获工作者线程的控制函数
{
	CCapturePacketDlg* dlg = (CCapturePacketDlg*)theApp.m_pMainWnd; //获取对话框句柄

	int cur = dlg->m_list_interface.GetCurSel();// 获取listbox被选中的行的数目
	dlg->curdev = dlg->alldevs;
	while (cur--)
		dlg->curdev = dlg->curdev->next;

	char* errbuf = new char[100];

	// 在对某一网络接口卡进行监听之前，首先需要将其打开。打开某一网络接口设备可以使用 WinPcap 提供的 pcap_open() 函数
	dlg->adhandle = pcap_open(
		dlg->curdev->name // 需要打开的网卡的名字
		, 65536 // WinPcap 获取网络数据包的最大长度。设为 2^16
		, PCAP_OPENFLAG_PROMISCUOUS // 它通知系统以混杂模式打开网络接口设备。
		, 1000 // 数据包捕获函数等待一个数据包的最大时间，设为 1 秒
		, NULL // 在远程设备中捕获网络数据包时使用。在编写捕获本机网络数据包的应用程序中，需要将 auth 设置为 NULL
		, errbuf // 用户定义的存放错误信息的缓冲区。
	);

	// 调用出错时，pcap_open() 函数返回 NULL，可以通过 errbuf 获取错误的详细信息
	if (dlg->adhandle == NULL)
	{
		AfxMessageBox(_T("打开网卡出错：") + (CString)errbuf);
		return -1;
	}

	while (dlg->m_capStatus == true || dlg->m_arpCapStatus == true)
	{
		// 在打开的网络接口卡上捕获网络数据包
		int pkt = pcap_next_ex(
			dlg->adhandle, // pcap_next_ex() 函数通过该参数指定捕获哪块网卡上的网络数据包。
			&pkt_header, // 在 pcap_next_ex() 函数调用成功后，
						// 该参数指向的 pcap_pkthdr 结构保存有所捕获网络数据包的一些基本信息
			&pkt_data // pkt_data：指向捕获到的网络数据包。
		);

		// 如果在调用过程中发生错误，那么 pcap_next_ex() 函数将返回 -1
		if (pkt == -1)
		{
			AfxMessageBox(_T("在调用过程中发生错误，pcap_next_ex() 函数返回 -1"));
			return -2;
		}
		// 指定的时间范围内（read_timeout）没有捕获到任何网络数据包，那么 pcap_next_ex() 函数将返回 0
		else if (pkt == 0)
		{
			// AfxMessageBox(_T("指定的时间范围内（read_timeout）没有捕获到任何网络数据包，pcap_next_ex() 函数返回 0"));
			// return -3;
			continue;
		}
		// 如果 pcap_next_ex() 函数，正确捕获到一个数据包，那么，它将返回 1。
		else if (pkt == 1)
		{

			dlg->SendMessage(WM_PACKET, 0, 0); // SendMessage 为同步式的消息发送，
											// 它将消息放入窗口的消息队列后等待消息被处理后返回
		}
	}


	return 0;
}

void CCapturePacketDlg::OnBnClickedButtoncapture()
{
	m_capStatus = true;
	m_capture.EnableWindow(false);
	m_stopCapture.EnableWindow(true);

	// 调用 AfxBeginThread() 函数启动工作者线程
	// AfxBeginThread() 函数将返回一个指向新创建线程对象的指针
	m_Capturer = AfxBeginThread(
		(AFX_THREADPROC)Capturer, // pfnThreadProc：指向工作者线程的控制函数，它的值不能为NULL
		NULL, // 
		THREAD_PRIORITY_NORMAL // 用于指定线程的优先级
	);

	if (m_Capturer == NULL) {
		AfxMessageBox(L"启动捕获数据包线程失败!", MB_OK | MB_ICONERROR);
		return;
	}
	else   /*打开选择的网卡 */
	{
		CString temp = _T("监听 ") + (CString(curdev->description)) + _T("\r\n");
		displayString(m_log, temp + bar);
	}
	UpdateData(true);
	Invalidate(true);
	UpdateWindow();
}

void CCapturePacketDlg::OnSelchangeListinterface()
{
	int cur = m_list_interface.GetCurSel();// 获取listbox被选中的行的数目

	// 找到当前指向的设备
	curdev = alldevs;
	while (cur--)
		curdev = curdev->next;
	UpdateInfo();
}

void CCapturePacketDlg::UpdateInfo()
{
	// 更新捕获接口的详细信息
	m_list_interfaceInfo.ResetContent();// 清除原有框的内容
	m_list_interfaceInfo.InsertString(-1, (CString(curdev->name)));			// 显示该网络接口设备的名字
	m_list_interfaceInfo.InsertString(-1, (CString(curdev->description)));	// 显示该网络接口设备的描述信息

	sockaddr_in* temp;
	IN_ADDR temp1;
	char* temp_data;
	CString output;
	CString IP; // 存放 IP 的临时变量
	for (pcap_addr* a = curdev->addresses; a != NULL; a = a->next)
	{
		if (a->addr->sa_family == AF_INET) // 判断地址是否为 IP 地址
		{
			temp = (sockaddr_in*)(a->addr);
			temp1 = temp->sin_addr;
			temp_data = inet_ntoa(temp1); // inet_ntoa 函数转换网络字节排序的地址为标准的ASCII以点分开的地址,该函数返回指向点分开的字符串地址的指针
			output = _T("IP address: ") + (CString(temp_data)); // 获取 IP 地址
			m_list_interfaceInfo.InsertString(-1, output);

			IP = CString(temp_data);


			//map<CString, CString>::iterator it;
			//it = devMAC.find(IP);
			//if (it == devMAC.end()) // 如果在映射关系没有找到对应
			//{
			//	temp = (sockaddr_in*)(a->addr);
			//	temp1 = temp->sin_addr;
			//	temp_data = inet_ntoa(temp1); // inet_ntoa 函数转换网络字节排序的地址为标准的ASCII以点分开的地址,该函数返回指向点分开的字符串地址的指针
			//	GetSelfMACaddr(temp_data); // 获取 MAC 地址
			//	// devMAC[''] = ;
			//	it = devMAC.find(IP);
			//	// devMAC.insert(pair<CString, CString>(IP, output)); // 将本机网卡的 IP 和 MAC 地址的映射关系加入 map
			//	// output = _T("MAC address: ") + (CString(output));
			//	m_list_interfaceInfo.InsertString(-1, _T("MAC address: ") + it->second);
			//}
			//else // 如果在映射关系中找到了对应
			//{
			//	m_list_interfaceInfo.InsertString(-1, _T("MAC address: ") + it->second);
			//}


			temp = (sockaddr_in*)(a->netmask);
			temp1 = temp->sin_addr;
			temp_data = inet_ntoa(temp1);
			output = _T("Netmask: ") + (CString(temp_data)); // 获取网络掩码
			m_list_interfaceInfo.InsertString(-1, output);

			temp = (sockaddr_in*)(a->broadaddr);
			temp1 = temp->sin_addr;
			temp_data = inet_ntoa(temp1);
			output = _T("Broadcast address: ") + (CString(temp_data)); // 获取广播地址
			m_list_interfaceInfo.InsertString(-1, output);

			temp = (sockaddr_in*)(a->dstaddr);
			if (temp != nullptr)
			{
				temp1 = temp->sin_addr;
				temp_data = inet_ntoa(temp1);
				output = _T("Destination address: ") + (CString(temp_data)); // 获取目的地址
				m_list_interfaceInfo.InsertString(-1, output);
			}
		}
	}

	return void();
}

void CCapturePacketDlg::SendARP(BYTE* SrcMAC, BYTE* SendHa, DWORD SendIP, DWORD RecvIP)
{
	ARPFrame_t ARPFrame;

	// 将 ARPFrame.FrameHeader.DesMAC 设置为广播地址
	// 将 ARPFrame.FrameHeader.SrcMAC 设置为本机网卡的 MAC 地址
	for (int i = 0; i < 6; ++i)
	{
		ARPFrame.FrameHeader.DesMAC[i] = 0xff;
		ARPFrame.FrameHeader.SrcMAC[i] = (SrcMAC[i]);
	}

	ARPFrame.FrameHeader.FrameType = htons(0x0806); // 帧类型为ARP

	ARPFrame.HardwareType = htons(0x0001); // 硬件类型为以太网
	ARPFrame.ProtocolType = htons(0x0800); // 协议类型为 IP
	ARPFrame.HLen = 6; // 硬件地址长度为 6
	ARPFrame.PLen = 4; // 协议地址长度为 4
	ARPFrame.Operation = htons(0x0001); // 操作为 ARP 请求

	// 将 ARPFrame.SendHa 设置为本机网卡的 MAC 地址
	// 将 ARPFrame.SendIP 设置为本机网卡上绑定的 IP 地址
	// 将 ARPFrame.RecvHa 设置为 0
	// 将 ARPFrame.RecvIP 设置为请求的 IP 地址
	for (int i = 0; i < 6; ++i)
	{
		ARPFrame.SendHa[i] = (SrcMAC[i]);
		ARPFrame.RecvHa[i] = 0x00;
	}
	ARPFrame.SendIP = SendIP;
	ARPFrame.RecvIP = RecvIP;

	int cur = m_list_interface.GetCurSel();// 获取listbox被选中的行的数目
	curdev = alldevs;
	while (cur--)
		curdev = curdev->next;

	// 在对某一网络接口卡进行监听之前，首先需要将其打开。打开某一网络接口设备可以使用 WinPcap 提供的 pcap_open() 函数
	adhandle = pcap_open(
		curdev->name // 需要打开的网卡的名字
		, 65536 // WinPcap 获取网络数据包的最大长度。设为 2^16
		, PCAP_OPENFLAG_PROMISCUOUS // 它通知系统以混杂模式打开网络接口设备。
		, 1000 // 数据包捕获函数等待一个数据包的最大时间，设为 1 秒
		, NULL // 在远程设备中捕获网络数据包时使用。在编写捕获本机网络数据包的应用程序中，需要将 auth 设置为 NULL
		, errbuf // 用户定义的存放错误信息的缓冲区。
	);


	int ret = pcap_sendpacket(
		adhandle,	// 指定 pcap_sendpacket()（函数通过哪块接口网卡发送数据包）
		(u_char*)&ARPFrame, // 指向需要发送的数据包，该数据包应该包括各层的头部信息。
		sizeof(ARPFrame_t))// 指定发送数据包的大小
		;

	if (ret != 0)
	{
		CString errorStr;
		errorStr.Format(_T("pcap_sendpacket() 函数返回 -1.错误。"));
		AfxMessageBox(errorStr);
		// 发送错误处理
	}
	else
	{
		// 发送成功
		// Sleep(5000); //等待获取成功
	}

	return;
}

void CCapturePacketDlg::GetSelfMACaddr(char* IPaddr)
{
	m_arpCapStatus = true;
	// 调用 AfxBeginThread() 函数启动工作者线程
	// AfxBeginThread() 函数将返回一个指向新创建线程对象的指针
	m_Capturer = AfxBeginThread(
		(AFX_THREADPROC)Capturer, // pfnThreadProc：指向工作者线程的控制函数，它的值不能为NULL
		NULL, // 
		THREAD_PRIORITY_NORMAL // 用于指定线程的优先级
	);

	if (m_Capturer == NULL) {
		AfxMessageBox(L"启动捕获数据包线程失败!", MB_OK | MB_ICONERROR);
		return;
	}


	BYTE* SrcMAC = new BYTE[6];
	BYTE* SendHa = new BYTE[6];
	DWORD SendIP;
	DWORD RecvIP;

	//// 设置要发送的 ARP 数据帧
	//// 192.168.1.151 对应的 MAC 地址，用于调试
	//SrcMAC[0] = 0xec;
	//SrcMAC[1] = 0x5c;
	//SrcMAC[2] = 0x68;
	//SrcMAC[3] = 0xb7;
	//SrcMAC[4] = 0x6c;
	//SrcMAC[5] = 0xeb;
	for (int i = 0; i < 6; ++i)
	{
		SrcMAC[i] = (0x6a);
		SendHa[i] = (0x6a);
	}
	SendIP = inet_addr("123.123.123.123"); // 以 192.168.1.250 的名义发送 ARP 请求
	RecvIP = inet_addr(IPaddr);

	SendARP(SrcMAC, SendHa, SendIP, RecvIP);

	// m_gotARPreply = false; // 用于判断是否已捕获 ARP 回复

	return;
}

void CCapturePacketDlg::OnBnClickedButtonstopcapture()
{
	// TODO: 在此添加控件通知处理程序代码

	m_capStatus = false;
	m_capture.EnableWindow(true);
	m_stopCapture.EnableWindow(false);

	CString stop = _T("停止获取数据包。\r\n");
	displayString(m_log, stop + bar);
}


void CCapturePacketDlg::OnClose()
{
	// TODO: 在此添加消息处理程序代码和/或调用默认值

	pcap_freealldevs(alldevs);
	CDialogEx::OnClose();
}


void CCapturePacketDlg::OnBnClickedButtonreturn()
{
	// TODO: 在此添加控件通知处理程序代码

	m_log.SetWindowTextW(L"");
	m_IP_MAC_Map.SetWindowTextW(L"");
}


void CCapturePacketDlg::OnBnClickedButtongetmap()
{
	m_arpCapStatus = true;


	// 调用 AfxBeginThread() 函数启动工作者线程
	// AfxBeginThread() 函数将返回一个指向新创建线程对象的指针
	m_Capturer = AfxBeginThread(
		(AFX_THREADPROC)Capturer, // pfnThreadProc：指向工作者线程的控制函数，它的值不能为NULL
		NULL, // 
		THREAD_PRIORITY_NORMAL // 用于指定线程的优先级
	);

	if (m_Capturer == NULL) {
		AfxMessageBox(L"启动捕获数据包线程失败!", MB_OK | MB_ICONERROR);
	}


	BYTE* SrcMAC = new BYTE[6];
	BYTE* SendHa = new BYTE[6];
	DWORD SendIP;
	DWORD RecvIP;

	SrcMAC[0] = 0x50;
	SrcMAC[1] = 0x2b;
	SrcMAC[2] = 0x73;
	SrcMAC[3] = 0xd5;
	SrcMAC[4] = 0x50;
	SrcMAC[5] = 0xea;

	SendHa[0] = 0x50;
	SendHa[1] = 0x2b;
	SendHa[2] = 0x73;
	SendHa[3] = 0xd5;
	SendHa[4] = 0x50;
	SendHa[5] = 0xea;
	// 设置要发送的 ARP 数据帧
	//for (int i = 0; i < 6; ++i)
	//{
	//	// SrcMAC[i] = htons(66);
	//	SendHa[i] = htons(66);
	//}

	const char* ip = "192.168.1.161";
	SendIP = inet_addr(ip);// 先自行指定，之后再改
	RecvIP = htonl(m_IPaddress);

	// 转换成 CString 型 IP 地址，存入变量
	WORD hiWord = HIWORD(m_IPaddress);
	WORD loWord = LOWORD(m_IPaddress);
	BYTE nf1 = HIBYTE(hiWord);
	BYTE nf2 = LOBYTE(hiWord);
	BYTE nf3 = HIBYTE(loWord);
	BYTE nf4 = LOBYTE(loWord);
	strIPaddress.Format(L"%d.%d.%d.%d", nf1, nf2, nf3, nf4);

	SendARP(SrcMAC, SendHa, SendIP, RecvIP);
}


void CCapturePacketDlg::OnFieldchangedIpaddress(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMIPADDRESS pIPAddr = reinterpret_cast<LPNMIPADDRESS>(pNMHDR);
	// TODO: 在此添加控件通知处理程序代码

	UpdateData(true);

	*pResult = 0;
}

