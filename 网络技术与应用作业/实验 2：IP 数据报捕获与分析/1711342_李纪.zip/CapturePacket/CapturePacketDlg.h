﻿// CapturePacketDlg.h: 头文件
//

#pragma once
#include "pcap.h"


// CCapturePacketDlg 对话框
class CCapturePacketDlg : public CDialogEx
{
	// 构造
public:
	CCapturePacketDlg(CWnd* pParent = nullptr);	// 标准构造函数

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_CAPTUREPACKET_DIALOG };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV 支持


// 实现
protected:
	HICON m_hIcon;

	// 生成的消息映射函数
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();

	// 声明消息处理函数
	afx_msg LRESULT OnPacket(WPARAM wParam, LPARAM lParam);

	DECLARE_MESSAGE_MAP()
public:
	pcap_if_t* alldevs = nullptr; // 指向设备链表首部的指针
	pcap_if_t* curdev = nullptr; // 一个全局指针，指向当前选中的设备
	pcap_t* adhandle = nullptr; // 一个句柄
	CWinThread* m_Capturer = nullptr; // 启动工作者线程的指针
	char errbuf[PCAP_ERRBUF_SIZE]; // 错误倩息缓冲区
	bool m_capStatus = false; // 判断是否处于捕获状态
	// 在编辑控件中显示内容
	void displayString(CEdit& editCtrl, CString& str);
	afx_msg void OnBnClickedButtoncapture();
	// static UINT Capturer(PVOID hWnd); // 数据包捕获工作者线程的控制函数

	// 捕获报文按钮
	CButton m_capture;
	// 返回按钮
	CButton m_return;
	// 停止捕获按钮
	CButton m_stopCapture;
	// 过滤器控件
	CEdit m_filter;
	// 以太网接口编辑控件
//	CEdit m_interface;
	// 以太网接口信息编辑控件
//	CEdit m_interfaceInfo;
	// 日志控件
	CEdit m_log;
	// 网络接口列表
	CListBox m_list_interface;
	// 网络接口信息列表
	CListBox m_list_interfaceInfo;
	afx_msg void OnSelchangeListinterface();
	void UpdateInfo(); // 更新捕获接口的详细信息框
	afx_msg void OnBnClickedButtonstopcapture();
	afx_msg void OnClose();
	afx_msg void OnBnClickedButtonreturn();
};

// 全局函数
UINT Capturer(PVOID hWnd); // 数据包捕获工作者线程的控制函数

#pragma pack(1)		//进入字节对齐方式
typedef struct FrameHeader_t {	//帧首部
	BYTE	DesMAC[6];	// 目的地址
	BYTE 	SrcMAC[6];	// 源地址
	WORD	FrameType;	// 帧类型
} FrameHeader_t;

typedef struct IPHeader_t {		// IP 首部
	BYTE	Ver_HLen;
	BYTE	TOS;
	WORD	TotalLen;
	WORD	ID;
	WORD	Flag_Segment;
	BYTE	TTL;
	BYTE	Protocol;
	WORD	Checksum;
	ULONG	SrcIP;
	ULONG	DstIP;
	WORD	Opt[20];
} IPHeader_t;

typedef struct Data_t {	// 包含帧首部和 IP 首部的数据包
	FrameHeader_t	FrameHeader;
	IPHeader_t		IPHeader;
} Data_t;

#pragma pack()	// 恢复缺省对齐方式