﻿
// CapturePacketDlg.cpp: 实现文件
//

#include "pch.h"
#include "framework.h"
#include "CapturePacket.h"
#include "CapturePacketDlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#define WM_PACKET WM_USER+1

pcap_pkthdr* pkt_header;
const u_char* pkt_data;
CString bar = _T("------------------------------------------------------\r\n");

// #define _CRT_SECURE_NO_WARNINGS

// 用于应用程序“关于”菜单项的 CAboutDlg 对话框

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

	// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

// 实现
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CCapturePacketDlg 对话框



CCapturePacketDlg::CCapturePacketDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_CAPTUREPACKET_DIALOG, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CCapturePacketDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_BUTTONCAPTURE, m_capture);
	DDX_Control(pDX, IDC_BUTTONRETURN, m_return);
	DDX_Control(pDX, IDC_BUTTONSTOPCAPTURE, m_stopCapture);
	DDX_Control(pDX, IDC_EDITFILTER, m_filter);
	/*DDX_Control(pDX, IDC_EDITINTERFACE, m_interface);
	DDX_Control(pDX, IDC_EDITINTERFACEINFO, m_interfaceInfo);*/
	DDX_Control(pDX, IDC_EDITLOG, m_log);
	DDX_Control(pDX, IDC_LISTINTERFACE, m_list_interface);
	DDX_Control(pDX, IDC_LISTINTERFACEINFO, m_list_interfaceInfo);
}

BEGIN_MESSAGE_MAP(CCapturePacketDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTONCAPTURE, &CCapturePacketDlg::OnBnClickedButtoncapture)
	ON_LBN_SELCHANGE(IDC_LISTINTERFACE, &CCapturePacketDlg::OnSelchangeListinterface)

	// 进行消息映射
	ON_MESSAGE(WM_PACKET, OnPacket)

	ON_BN_CLICKED(IDC_BUTTONSTOPCAPTURE, &CCapturePacketDlg::OnBnClickedButtonstopcapture)
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDC_BUTTONRETURN, &CCapturePacketDlg::OnBnClickedButtonreturn)
END_MESSAGE_MAP()


// CCapturePacketDlg 消息处理程序

BOOL CCapturePacketDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// 将“关于...”菜单项添加到系统菜单中。

	// IDM_ABOUTBOX 必须在系统命令范围内。
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != nullptr)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// 设置此对话框的图标。  当应用程序主窗口不是对话框时，框架将自动
	//  执行此操作
	SetIcon(m_hIcon, TRUE);			// 设置大图标
	SetIcon(m_hIcon, FALSE);		// 设置小图标

	// TODO: 在此添加额外的初始化代码

	
	int i = 0; // 标识找到 i 个设备

	/* Retrieve the device list */
	if (pcap_findalldevs_ex(PCAP_SRC_IF_STRING, NULL, &alldevs, errbuf) == -1)
	{
		fprintf(stderr, "Error in pcap_findalldevs: %s\n", errbuf);
		AfxMessageBox((CString)errbuf);
		exit(1);
	}

	/* Print the list */
	for (pcap_if_t* d = alldevs; d; d = d->next)
		m_list_interface.InsertString(-1, (CString)("%d. %s\r\n", ++i, d->name));
	UpdateData(true);
	Invalidate(true);
	UpdateWindow(); // 更新窗口

	if (i == 0) // 如果没有检测到设备
	{
		AfxMessageBox(_T("No interfaces found! Make sure Npcap is installed."));
		return -1;
	}


	m_list_interface.SetCurSel(0); // 默认选中第一行
	int cur = m_list_interface.GetCurSel(); // 获取listbox被选中的行的数目

	// 找到当前指向的设备
	curdev = alldevs;
	while (cur--)
		curdev = curdev->next;
	UpdateInfo();

	// 禁用“停止捕获”控件
	m_stopCapture.EnableWindow(false);

	return TRUE;  // 除非将焦点设置到控件，否则返回 TRUE
}

void CCapturePacketDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// 如果向对话框添加最小化按钮，则需要下面的代码
//  来绘制该图标。  对于使用文档/视图模型的 MFC 应用程序，
//  这将由框架自动完成。

void CCapturePacketDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // 用于绘制的设备上下文

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// 使图标在工作区矩形中居中
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// 绘制图标
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

//当用户拖动最小化窗口时系统调用此函数取得光标
//显示。
HCURSOR CCapturePacketDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CCapturePacketDlg::displayString(CEdit& editCtrl, CString& str)
{
	CString tmp;
	// tmp.Append(_T("\r\n"));
	editCtrl.GetWindowTextW(tmp);
	editCtrl.SetWindowTextW(tmp + str);
	/*UpdateData(true);
	Invalidate(true);
	UpdateWindow();*/
}

// 定义一个前十六位全为 0，后十六位全为 1 的常量
const DWORD overflowCrush = 0b00000000000000001111111111111111; 
WORD CheckOverflow(DWORD& now)
{
	// 如果现在的数比 max(WORD) 大了，说明溢出了
	if (now > WORD_MAX)
	{
		// 回卷
		now = overflowCrush & now;
		now++;
	}
	return now;
}

WORD IpCheckSum(IPHeader_t IPHeader)
{
	// 考虑可能溢出，采用 DWORD 类型
	DWORD CheckSum, temp1, temp2;

	// 按照算法一步一步做
	temp1 = (IPHeader.TOS << 8) + IPHeader.Ver_HLen;
	temp2 = IPHeader.TotalLen;
	CheckSum = temp1 + temp2;
	CheckOverflow(CheckSum);

	temp1 = IPHeader.ID;
	temp2 = CheckSum;
	CheckSum = temp1 + temp2;
	CheckOverflow(CheckSum);

	temp1 = IPHeader.Flag_Segment;
	temp2 = CheckSum;
	CheckSum = temp1 + temp2;
	CheckOverflow(CheckSum);

	temp1 = (IPHeader.Protocol << 8) + IPHeader.TTL;
	temp2 = CheckSum;
	CheckSum = temp1 + temp2;
	CheckOverflow(CheckSum);

	// IP 数据报的头部校验和就不加了

	temp1 = IPHeader.SrcIP >> 16;
	temp2 = CheckSum;
	CheckSum = temp1 + temp2;
	CheckOverflow(CheckSum);

	temp1 = IPHeader.SrcIP & overflowCrush;
	temp2 = CheckSum;
	CheckSum = temp1 + temp2;
	CheckOverflow(CheckSum);

	temp1 = IPHeader.DstIP >> 16;
	temp2 = CheckSum;
	CheckSum = temp1 + temp2;
	CheckOverflow(CheckSum);

	temp1 = IPHeader.DstIP & overflowCrush;
	temp2 = CheckSum;
	CheckSum = temp1 + temp2;
	CheckOverflow(CheckSum);

	// 考虑可选和填充部分
	int HLen = IPHeader.Ver_HLen & 0x0f;
	int OptLen = HLen - 5;

	for (int i = 0; i < OptLen; ++i)
	{
		temp1 = IPHeader.Opt[i];
		temp2 = CheckSum;
		CheckSum = temp1 + temp2;
		CheckOverflow(CheckSum);
	}

	return (~((WORD)CheckSum));
}

// 消息处理函数
LRESULT CCapturePacketDlg::OnPacket(WPARAM wParam, LPARAM lParam)
{
	// 处理捕获到的数据包

	Data_t* IPPacket;
	WORD RecvChecksum; // 头部校验和
	WORD Identifier; // 标识
	WORD CheckSum; // 计算出的头部校验和


	IPPacket = (Data_t*)pkt_data;
	WORD FrameType = (IPPacket->FrameHeader.FrameType);
	BYTE Ver_HLen = (IPPacket->IPHeader.Ver_HLen >> 4);

	

	// IPv6 没有头部校验和，下面是维基百科的说法
	// In order to increase performance, 
	// and since current link layer technology and transport or application layer protocols are assumed to provide sufficient error detection, 
	// the header has no checksum to protect it.

	if (FrameType == 8 && Ver_HLen == 4) // 保证是 IP 数据报，保证版本为 IPv4
	// if (FrameType == 2048) // 保证是 IP 数据报，保证版本正确
	{
		Identifier = IPPacket->IPHeader.ID;
		RecvChecksum = IPPacket->IPHeader.Checksum;
		CheckSum = IpCheckSum(IPPacket->IPHeader);

		// 下面是输出
		// 时间输出
		CString timeStr;
		timeStr.Format(_T(" %d "), pkt_header->ts.tv_sec);
		time_t t = pkt_header->ts.tv_sec;
		tm* timeptr = localtime(&t);
		char buffer[80];
		strftime(buffer, sizeof(buffer), "%Y/%m/%d %H:%M:%S", timeptr);
		timeStr.Format(_T("%s.%d"), (CString)buffer, pkt_header->ts.tv_usec);

		// IP 报文头长度输出
		CString len;
		// len.Format(_T(" len: %d  FrameType: %d\r\n"), pkt_header->caplen, FrameType);
		// len.Format(_T(" len: %d  Ver_HLen: %d\r\n"), pkt_header->caplen, Ver_HLen);
		len.Format(_T(" len: %d \r\n"), IPPacket->IPHeader.TotalLen);
		displayString(m_log, timeStr + len);

		// 标识：头部校验和：计算出的头部校验和：
		CString info;
		info.Format(_T("标识：%04x  头部校验和： %04x  计算出的头部校验和：%04x\r\n"), 
			ntohs(Identifier), ntohs(RecvChecksum), ntohs(CheckSum));
		//info.Format(_T("标识：%04x  头部校验和： %04x  计算出的头部校验和：%04x\r\n"),
		//	(Identifier), (RecvChecksum), (CheckSum));
		displayString(m_log, info + bar);
	}


	return LRESULT();
}


// error C2440: “类型转换” : 无法从“overloaded-function”转换为 xxx
// 原因：线程函数需要静态成员函数或全局函数

UINT Capturer(PVOID hWnd) // 数据包捕获工作者线程的控制函数
{
	CCapturePacketDlg* dlg = (CCapturePacketDlg*)theApp.m_pMainWnd; //获取对话框句柄

	int cur = dlg->m_list_interface.GetCurSel();// 获取listbox被选中的行的数目
	dlg->curdev = dlg->alldevs;
	while (cur--)
		dlg->curdev = dlg->curdev->next;

	char* errbuf = new char[100];

	// 在对某一网络接口卡进行监听之前，首先需要将其打开。打开某一网络接口设备可以使用 WinPcap 提供的 pcap_open() 函数
	dlg->adhandle = pcap_open(
		dlg->curdev->name // 需要打开的网卡的名字
		, 65536 // WinPcap 获取网络数据包的最大长度。设为 2^16
		, PCAP_OPENFLAG_PROMISCUOUS // 它通知系统以混杂模式打开网络接口设备。
		, 1000 // 数据包捕获函数等待一个数据包的最大时间，设为 1 秒
		, NULL // 在远程设备中捕获网络数据包时使用。在编写捕获本机网络数据包的应用程序中，需要将 auth 设置为 NULL
		, errbuf // 用户定义的存放错误信息的缓冲区。
	);

	// 调用出错时，pcap_open() 函数返回 NULL，可以通过 errbuf 获取错误的详细信息
	if (dlg->adhandle == NULL)
	{
		AfxMessageBox(_T("打开网卡出错：") + (CString)errbuf);
		return -1;
	}


	while (dlg->m_capStatus == true)
	{
		// 在打开的网络接口卡上捕获网络数据包
		int pkt = pcap_next_ex(
			dlg->adhandle, // pcap_next_ex() 函数通过该参数指定捕获哪块网卡上的网络数据包。
			&pkt_header, // 在 pcap_next_ex() 函数调用成功后，
						// 该参数指向的 pcap_pkthdr 结构保存有所捕获网络数据包的一些基本信息
			&pkt_data // pkt_data：指向捕获到的网络数据包。
		);

		// 如果在调用过程中发生错误，那么 pcap_next_ex() 函数将返回 -1
		if (pkt == -1)
		{
			AfxMessageBox(_T("在调用过程中发生错误，pcap_next_ex() 函数返回 -1"));
			return -2;
		}
		// 指定的时间范围内（read_timeout）没有捕获到任何网络数据包，那么 pcap_next_ex() 函数将返回 0
		else if (pkt == 0)
		{
			// AfxMessageBox(_T("指定的时间范围内（read_timeout）没有捕获到任何网络数据包，pcap_next_ex() 函数返回 0"));
			// return -3;
			continue;
		}
		// 如果 pcap_next_ex() 函数，正确捕获到一个数据包，那么，它将返回 1。
		else if (pkt == 1)
		{

			dlg->SendMessage(WM_PACKET, 0, 0); // SendMessage 为同步式的消息发送，
											// 它将消息放入窗口的消息队列后等待消息被处理后返回
		}
	}


	return 0;
}

void CCapturePacketDlg::OnBnClickedButtoncapture()
{
	m_capStatus = true;
	m_capture.EnableWindow(false);
	m_stopCapture.EnableWindow(true);

	// 调用 AfxBeginThread() 函数启动工作者线程
	// AfxBeginThread() 函数将返回一个指向新创建线程对象的指针
	m_Capturer = AfxBeginThread(
		(AFX_THREADPROC)Capturer, // pfnThreadProc：指向工作者线程的控制函数，它的值不能为NULL
		NULL, // 
		THREAD_PRIORITY_NORMAL // 用于指定线程的优先级
	);

	if (m_Capturer == NULL) {
		AfxMessageBox(L"启动捕获数据包线程失败!", MB_OK | MB_ICONERROR);
		return;
	}
	else   /*打开选择的网卡 */
	{
		CString temp = _T("监听 ") + (CString(curdev->description)) + _T("\r\n");
		displayString(m_log, temp + bar);
	}
	UpdateData(true);
	Invalidate(true);
	UpdateWindow();
}

void CCapturePacketDlg::OnSelchangeListinterface()
{
	int cur = m_list_interface.GetCurSel();// 获取listbox被选中的行的数目

	// 找到当前指向的设备
	curdev = alldevs;
	while (cur--)
		curdev = curdev->next;
	UpdateInfo();
}

void CCapturePacketDlg::UpdateInfo()
{
	// 更新捕获接口的详细信息
	m_list_interfaceInfo.ResetContent();// 清除原有框的内容
	m_list_interfaceInfo.InsertString(-1, (CString(curdev->name)));			// 显示该网络接口设备的名字
	m_list_interfaceInfo.InsertString(-1, (CString(curdev->description)));	// 显示该网络接口设备的描述信息

	sockaddr_in* temp;
	IN_ADDR temp1;
	char* temp_data;
	CString output;
	for (pcap_addr* a = curdev->addresses; a != NULL; a = a->next)
	{
		if (a->addr->sa_family == AF_INET) // 判断地址是否为 IP 地址
		{
			temp = (sockaddr_in*)(a->addr);
			temp1 = temp->sin_addr;
			temp_data = inet_ntoa(temp1);
			output = _T("IP address: ") + (CString(temp_data)); // 获取 IP 地址
			m_list_interfaceInfo.InsertString(-1, output);

			temp = (sockaddr_in*)(a->netmask);
			temp1 = temp->sin_addr;
			temp_data = inet_ntoa(temp1);
			output = _T("Netmask: ") + (CString(temp_data)); // 获取网络掩码
			m_list_interfaceInfo.InsertString(-1, output);

			temp = (sockaddr_in*)(a->broadaddr);
			temp1 = temp->sin_addr;
			temp_data = inet_ntoa(temp1);
			output = _T("Broadcast address: ") + (CString(temp_data)); // 获取广播地址
			m_list_interfaceInfo.InsertString(-1, output);

			temp = (sockaddr_in*)(a->dstaddr);
			if (temp != nullptr)
			{
				temp1 = temp->sin_addr;
				temp_data = inet_ntoa(temp1);
				output = _T("Destination address: ") + (CString(temp_data)); // 获取目的地址
				m_list_interfaceInfo.InsertString(-1, output);
			}
		}
	}

	return void();
}

void CCapturePacketDlg::OnBnClickedButtonstopcapture()
{
	// TODO: 在此添加控件通知处理程序代码

	m_capStatus = false;
	m_capture.EnableWindow(true);
	m_stopCapture.EnableWindow(false);

	CString stop = _T("停止获取数据包。\r\n");
	displayString(m_log, stop + bar);
}


void CCapturePacketDlg::OnClose()
{
	// TODO: 在此添加消息处理程序代码和/或调用默认值

	pcap_freealldevs(alldevs);
	CDialogEx::OnClose();
}


void CCapturePacketDlg::OnBnClickedButtonreturn()
{
	// TODO: 在此添加控件通知处理程序代码

	m_log.SetWindowTextW(L"");
}
