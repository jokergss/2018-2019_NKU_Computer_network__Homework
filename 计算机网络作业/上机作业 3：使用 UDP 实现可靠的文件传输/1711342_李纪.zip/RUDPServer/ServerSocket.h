﻿#pragma once
#include<string>
#include<map>
#include<vector>

#define MAX_PACKET 7000

// ServerSocket 命令目标

struct header {
	char fileName[260];//Windows下完全限定文件名必须少于260个字符，目录名必须小于248个字符。
	bool isAck;
	int seq;
	int clientPort;
	int serverPort;
	int dataLen;
	int totalLen;
};

struct tempForDownAndUp {//为了开启一个线程随意创建的临时变量
	CString strData;
	int clientPort;
	int initClientPort;
};

class ServerSocket : public CAsyncSocket
{
public:
	ServerSocket();
	virtual ~ServerSocket();
	virtual void OnSend(int nErrorCode);
	bool waitACK(ServerSocket& skt, header* hd);
	CString initReply100();
	void Reply110(CString str, int clientPort, int serverPort, ServerSocket& skt);
	void Reply120(CString str, int clientPort, int serverPort, ServerSocket& skt);
	char* CStringToPChar(CString str);
	virtual void OnReceive(int nErrorCode);
	virtual void OnAccept(int nErrorCode);
	bool processFile(ServerSocket& skt, char* raw, int clientPort);
	std::map<int, std::vector<int> > clientPortMap;
};


