﻿#pragma once
#include <fstream>
#include <map>

#define MAX_PACKET 7000
// ClientSocket 命令目标
struct header {
	char fileName[260];//Windows下完全限定文件名必须少于260个字符，目录名必须小于248个字符。
	bool isAck;
	int seq;
	int clientPort;
	int serverPort;
	int dataLen;
	int totalLen;
};

struct tempUpload {
	CString filePath;
	//int initClientPort;
};

class ClientSocket : public CAsyncSocket
{
public:
	ClientSocket();
	virtual ~ClientSocket();
	void initReceive200(CString s);
	int waitFor220(ClientSocket& skt, int clientPort);
	bool uploadFile(CString filePath, ClientSocket& skt, int clientPort, int serverPort);
	bool waitACK(ClientSocket& skt, header* hd);
	virtual void OnReceive(int nErrorCode);
	bool processFile(ClientSocket& skt, char* raw,int clientPort);
};


