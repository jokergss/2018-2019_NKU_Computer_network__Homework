﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 RUDPClient.rc 使用
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_RUDPCLIENT_DIALOG           102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define IDC_EDIT_IP                     1001
#define IDC_EDIT_PORT                   1002
#define IDC_BUTTON_CONNECT              1003
#define IDC_BUTTON_DOWNLOAD             1006
#define IDC_EDIT_LOG                    1007
#define IDC_LIST_FILE                   1010
#define IDC_BUTTON_UPLOAD               1011
#define IDC_BUTTON1                     1012
#define IDC_BUTTON_CLEAR                1012

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
