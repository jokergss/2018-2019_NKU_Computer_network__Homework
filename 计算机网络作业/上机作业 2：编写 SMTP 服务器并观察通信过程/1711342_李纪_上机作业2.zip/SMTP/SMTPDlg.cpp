﻿
// SMTPDlg.cpp: 实现文件
//

#include "pch.h"
#include "framework.h"
#include "SMTP.h"
#include "SMTPDlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// 用于应用程序“关于”菜单项的 CAboutDlg 对话框

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

// 实现
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CSMTPDlg 对话框



CSMTPDlg::CSMTPDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_SMTP_DIALOG, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CSMTPDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_ATTACHMENTNAME, m_attachmentName);
	DDX_Control(pDX, IDC_LOG, m_log);
	//DDX_Control(pDX, IDC_MESSEGE, m_messege);
	//DDX_Control(pDX, IDC_TEXT, m_text);
	DDX_Control(pDX, IDC_PICTURE, m_picture);
	DDX_Control(pDX, IDC_CLEAR, m_clear);
	DDX_Control(pDX, IDC_START, m_start);
	DDX_Control(pDX, IDC_EDITMESSEGE, m_message);
	DDX_Control(pDX, IDC_EDITTEXT, m_text);
	DDX_Control(pDX, IDC_EDITATTACHMENTTEXT, m_attachmentText);
	DDX_Control(pDX, IDC_BUTTONPICTURE, m_pictureButton);
}

BEGIN_MESSAGE_MAP(CSMTPDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_START, &CSMTPDlg::OnBnClickedStart)
	ON_BN_CLICKED(IDC_CLEAR, &CSMTPDlg::OnBnClickedClear)
	ON_BN_CLICKED(IDC_BUTTONPICTURE, &CSMTPDlg::OnBnClickedButtonpicture)
END_MESSAGE_MAP()


// CSMTPDlg 消息处理程序

BOOL CSMTPDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// 将“关于...”菜单项添加到系统菜单中。

	// IDM_ABOUTBOX 必须在系统命令范围内。
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != nullptr)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// 设置此对话框的图标。  当应用程序主窗口不是对话框时，框架将自动
	//  执行此操作
	SetIcon(m_hIcon, TRUE);			// 设置大图标
	SetIcon(m_hIcon, FALSE);		// 设置小图标

	// TODO: 在此添加额外的初始化代码



	return TRUE;  // 除非将焦点设置到控件，否则返回 TRUE
}

void CSMTPDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// 如果向对话框添加最小化按钮，则需要下面的代码
//  来绘制该图标。  对于使用文档/视图模型的 MFC 应用程序，
//  这将由框架自动完成。

void CSMTPDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // 用于绘制的设备上下文

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// 使图标在工作区矩形中居中
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// 绘制图标
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

//当用户拖动最小化窗口时系统调用此函数取得光标
//显示。
HCURSOR CSMTPDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CSMTPDlg::displayString(CEdit& editCtrl, CString& str)
{
	CString tmp;
	// tmp.Append(_T("\r\n"));
	editCtrl.GetWindowTextW(tmp);
	editCtrl.SetWindowTextW(tmp + str);
	/*UpdateData(true);
	Invalidate(true);
	UpdateWindow();*/
}

void CSMTPDlg::OnBnClickedStart()
{
	// 如果不在监听状态
	if (!isListen)
	{
		// 更新日志
		m_log.InsertString(-1,(L"SMTP Server starts. \n"));

		// 绑定 TCP 端口 25
		BOOL bFlag = listen.Create(25, SOCK_STREAM, FD_ACCEPT);

		if (!bFlag)
		{
			// 如果创建 Socket 报错，执行下面的代码
			int error = listen.GetLastError();
			AfxMessageBox(_T("Listen Socket Create Failed. Error: " + error));
			listen.Close();
			return;
		}

		// 开始监听
		if (!listen.Listen())
		{
			// 如果 Socket 监听报错，执行下面的代码
			int error = listen.GetLastError();
			AfxMessageBox(_T("Listen Socket Listen Failed. Error: " + error));
			listen.Close();
			return;
		}
		else
		{
			// 更新日志
			m_log.InsertString(-1,(L"TCP Socket listening now. At Port: 25"));
		}

		// 更新监听状态
		isListen = true;
		// 更新控件显示
		m_start.SetWindowTextW(L"Shut down");
	}
	// 如果在监听状态
	else
	{
		// 关闭 Socket
		listen.Close();
		// 更新日志
		m_log.InsertString(-1,(_T("Server shut down.\r\n")));
		// 更新控件显示
		m_start.SetWindowTextW(L"Start");
		// 更新监听状态
		isListen = false;
	}
}


void CSMTPDlg::OnBnClickedClear()
{
	// 清空对话框内的内容

	m_message.SetWindowTextW(_T(""));
	m_text.SetWindowTextW(_T(""));
	m_attachmentName.SetWindowTextW(_T(""));
	m_attachmentText.SetWindowTextW(_T(""));
	m_picture.SetBitmap(NULL);
	m_log.ResetContent();
}


void CSMTPDlg::OnBnClickedButtonpicture()
{
	// 是否用默认程序打开图片列表里的图片
	if (!openPictures)
	{
		openPictures = true;
		m_pictureButton.SetWindowTextW(_T("Pictures will be opened"));
	}
	else
	{
		openPictures = false;
		m_pictureButton.SetWindowTextW(_T("Pictures Open Button"));
	}
}
