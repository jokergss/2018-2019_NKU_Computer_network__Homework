﻿// ListenServer.cpp: 实现文件
//

#include "pch.h"
#include "SMTP.h"
#include "ListenServer.h"
#include "ServerSocket.h"
#include "SMTPDlg.h"

using namespace std;

// ListenServer

ListenServer::ListenServer()
{
}

ListenServer::~ListenServer()
{
}


// ListenServer 成员函数

//应该是使用CSocket进行编程吧，AsyncSelect括号内的参数是诸如FD_CONNECT、FD_WRITE、FD_READ这些常量，AsyncSelect是投递事件用的，比如你这样写：AcceptSocket.AsyncSelect(FD_READ)就投递一个“读“的事件，准备接收，如果有读事件的时候，那么CSocket类的OnReceive事件就会触发，如果传入FD_WRITE就投了一个“写”事件，那么当发送数据的时候，你的OnSend事件就会触发。可以用 | 来表示需要监听多个事件。
//2.你需要监听连接的话，就传个FD_CONNECT给AcceptSocket.AsyncSelect()，那么在有连接事件的时候，就会触发OnConnect事件。一般都不直接用CAsyncSocket的，而是从来派生一个类出来，然后自己重写某些函数，比如你要处理连接时的事件，那么你就重写该类的OnConnect函数。


void ListenServer::OnAccept(int nErrorCode)
{
	CSMTPDlg* pdlg = (CSMTPDlg*)AfxGetApp()->GetMainWnd(); // 获取指向主对话框的指针
	ServerSocket* socket = new ServerSocket(); // 创建一个新的服务器 Socket

	if (Accept(*socket)) // Accepts a connection on the socket.
	{
		char buffer[100] = "220 ready\r\n";
		socket->Send(buffer, strlen(buffer));
		pdlg->m_log.InsertString(-1, (L"S: 220 Ready For Mail Service"));
		
		// 投递一个“读“的事件，准备接收
		socket->AsyncSelect(FD_READ);

		// 将指针加入服务器指针列表
		list<ServerSocket*>::iterator it = socketPtrList.begin();
		socketPtrList.insert(it, socket);
	}
	// 如果连接出错，输出错误代码
	else
	{
		int error = socket->GetLastError();
		AfxMessageBox(_T("Accept error: ") + error);
		// 关闭 Socket
		socket->Close();
		delete socket;
	}

	CAsyncSocket::OnAccept(nErrorCode);
}


void ListenServer::OnClose(int nErrorCode)
{
	// 清空 Socket 列表，释放空间
	while (!socketPtrList.empty())
	{
		ServerSocket* socket = socketPtrList.back();
		socket->Close();
		delete socket;
		socketPtrList.pop_back();
	}
	CAsyncSocket::OnClose(nErrorCode);
}
