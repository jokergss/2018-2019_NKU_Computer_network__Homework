﻿// ServerSocket.cpp: 实现文件
//

#include "pch.h"
#include "SMTP.h"
#include "ServerSocket.h"
#include "SMTPDlg.h"


using namespace std;


// ServerSocket

ServerSocket::ServerSocket()
{
	// 构建 base64 映射表
	for (int i = 0; i <= 'Z' - 'A'; ++i)
	{
		int temp = 'A' + i;
		char temp_char(temp);
		base64_map.insert(pair<char, int>(temp_char, i));
	}
	for (int i = 26; i <= 'z' - 'a' + 26; ++i)
	{
		int temp = 'a' + i - 26;
		char temp_char(temp);
		base64_map.insert(pair<char, int>(temp_char, i));
	}
	for (int i = 52; i <= '9' - '0' + 52; ++i)
	{
		int temp = '0' + i - 52;
		char temp_char(temp);
		base64_map.insert(pair<char, int>(temp_char, i));
	}
	base64_map.insert(pair<char, int>('+', 62));
	base64_map.insert(pair<char, int>('/', 63));
}

ServerSocket::~ServerSocket()
{
}


// ServerSocket 成员函数

// 将 base64 编码后的字符解码
// 参数解释：
// char& c -> 待解码的字符
// 返回值：无
void ServerSocket::CheckSymbol(char& c)
{
	// 若 base64 编码后的符号为 '='，则自身更新为 0
	// '=' 设为 0 不会影响输出，因为在 ASCII 里，0 -> NULL
	if (c == '=') 
		c = 0;
	else
	{
		// 若为其他字符，则自身更新为解码后的值
		int temp = base64_map.find(c)->second;
		c = char(temp);
	}
}

// base64 图片解码函数
// 参数解释：
// string attachmentName -> 文件名, 
// string encoded_string -> 图片 base64 编码
// 返回值：CString 文件名
CString ServerSocket::base64_decode_picture(string attachmentName,string encoded_string)
{
	// 声明一个用于存储解码出的字符的队列容器
	queue<char>decoded_string;

	// 移除回车换行符
	size_t pos;
	while (pos = encoded_string.find('\r'))
	{
		// 满足下面这个条件就是没找到
		if (pos == encoded_string.npos)
			break;
		encoded_string.erase(pos, 1);
	}
	while (pos = encoded_string.find('\n'))
	{
		// 满足下面这个条件就是没找到
		if (pos == encoded_string.npos)
			break;
		encoded_string.erase(pos, 1);
	}


	pos = 0;
	while (pos < encoded_string.length())
	{
		// 读入 4 个 base64 编码后的字符
		char u, x, y, z;
		u = encoded_string[pos++];
		x = encoded_string[pos++];
		y = encoded_string[pos++];
		z = encoded_string[pos++];
		CheckSymbol(u); CheckSymbol(x); CheckSymbol(y); CheckSymbol(z);


		// 声明解码后得到的 3 个字符 i, j, k, 临时变量 temp1, temp2
		char i, j, k, temp1, temp2;
		i = j = k = 0b00000000;

		// 按照编码算法反向思考，解码
		temp1 = u << 2; temp2 = x >> 4;
		i |= temp1; i |= temp2;


		temp1 = x << 4; temp2 = y >> 2;
		j |= temp1; j |= temp2;


		temp1 = y << 6; temp2 = z;
		k |= temp1; k |= temp2;

		// 将解码后的字符放入之前声明的队列
		decoded_string.push(i);
		decoded_string.push(j);
		decoded_string.push(k);
	}

	// 将解码后的字符流写入文件
	CString FileName(attachmentName.c_str());

	CFile file;
	// 以 Create 方式和 Write 方式打开文件
	// 若文件已存在就会清空后再写入
	BOOL bOpen = file.Open(FileName, CFile::modeCreate | CFile::modeWrite);
	if (bOpen)
	{
		file.SeekToEnd(); // 将指针移至文件末尾进行追加
		while (!decoded_string.empty())
		{
			// 一次循环写入一个字符
			file.Write((CString)decoded_string.front(), 1);
			decoded_string.pop();
		}
	}
	file.Close();

	return FileName;
}


// base64 解码
// 参数解释：
// string encoded_string -> base64 编码
// 返回值：string 解码出的字符串
string ServerSocket::base64_decode(string encoded_string)
{
	// 声明一个用于存储解码出的字符的字符串
	string decoded_string = "";

	// 移除回车换行符
	size_t pos;
	while (pos = encoded_string.find('\r'))
	{
		// 满足下面这个条件就是没找到
		if (pos == encoded_string.npos)
			break;
		encoded_string.erase(pos,1);
	}
	while (pos = encoded_string.find('\n'))
	{
		// 满足下面这个条件就是没找到
		if (pos == encoded_string.npos)
			break;
		encoded_string.erase(pos,1);
	}

	// 开始解码
	pos = 0;
	while (pos < encoded_string.length())
	{
		// 读入 4 个 base64 编码后的字符
		char u, x, y, z;
		u = encoded_string[pos++];
		x = encoded_string[pos++];
		y = encoded_string[pos++];
		z = encoded_string[pos++];

		// 将 base64 编码后的字符解码为 6 位二进制数
		CheckSymbol(u); CheckSymbol(x); CheckSymbol(y); CheckSymbol(z);


		// 声明解码后得到的 3 个字符 i, j, k, 临时变量 temp1, temp2
		char i, j, k, temp1, temp2;
		i = j = k = 0b00000000;

		// 按照编码算法反向思考，解码
		temp1 = u << 2; temp2 = x >> 4;
		i |= temp1; i |= temp2;


		temp1 = x << 4; temp2 = y >> 2;
		j |= temp1; j |= temp2;


		temp1 = y << 6; temp2 = z;
		k |= temp1; k |= temp2;

		// 将解码后的字符放入之前声明的字符串
		decoded_string = decoded_string + i + j + k;
	}

	// 在字符串中添加一个终止符号
	decoded_string += '\0';
	

	return decoded_string;
}


// 全局变量不会出现压栈出错的情况，扩大了能接收邮件大小的范围
char buffer[9999999]; // 创建一个用来存数据的缓存 理论上最多能存 9.5367 MB 左右的数据。
void ServerSocket::OnReceive(int nErrorCode)
{
	CSMTPDlg* pdlg = (CSMTPDlg*)AfxGetApp()->GetMainWnd(); // 获取指向主对话框的指针
	UINT revLength = Receive(buffer, sizeof(buffer)); // 获取客户端的回复

	buffer[revLength] = '\0'; // 获取到的数据的后一位换成字符串结束符 '\0'，不然消息显示会乱码
	CString str(buffer); // 生成一个 CString 类型的缓存


	// 下面的代码展示了服务器如何回复客户端
	if ((str.Left(4) == "EHLO") || (str.Left(4) == "HELO"))
	{
		pdlg->m_log.InsertString(-1,(L"C: " + str));
		char reply[100] = "250 hello\r\n";
		int s = Send(reply, strlen(reply));
		// int error = GetLastError();
		// AfxMessageBox(_T("Accept error: ") + error);
		AsyncSelect(FD_READ);
		pdlg->m_log.InsertString(-1,(L"S: 250 localhost"));
	}
	if (str.Left(10) == "MAIL FROM:")
	{
		pdlg->m_log.InsertString(-1,(L"C: " + str));
		char reply[100] = "250 OK\r\n";
		Send(reply, strlen(reply), 0);
		AsyncSelect(FD_READ);
		pdlg->m_log.InsertString(-1,(L"S: 250 OK"));
	}
	if (str.Left(8) == "RCPT TO:")
	{
		pdlg->m_log.InsertString(-1,(L"C: " + str));
		char reply[100] = "250 OK\r\n";
		Send(reply, strlen(reply), 0);
		AsyncSelect(FD_READ);
		pdlg->m_log.InsertString(-1,(L"S: 250 OK"));
	}
	if (str.Left(4) == "DATA")
	{
		pdlg->m_log.InsertString(-1,(L"C: " + str));
		char reply[100] = "354 Go ahead\r\n";
		Send(reply, strlen(reply), 0);
		AsyncSelect(FD_READ);
		pdlg->m_log.InsertString(-1,(L"S: 354 Go ahead"));

		// 标志着在下一次服务器的 Receive 中，客户端会传输数据过来
		data = true;
	}

	// 客户端传输的数据到来的时候
	if (data == true && str.Left(4) != "DATA")
	{
		// 显示未解码的邮件内容（即显示原生邮件报文）
		pdlg->displayString(pdlg->m_message,str);
		/*pdlg->UpdateData();
		pdlg->Invalidate();
		pdlg->UpdateWindow();*/


		// 邮件正文部分：
		// 找到邮件正文区
		string s(buffer);
		size_t pos1 = s.find("Content-Type: text/plain;");
		size_t pos2 = s.find("Content-Transfer-Encoding: base64", pos1);
		string temp = "Content-Transfer-Encoding: base64\r\n\r\n";
		pos2 += temp.length();
		size_t pos3 = s.find("\r\n\r\n", pos2);
		string truncated_str2 = s.substr(pos2, pos3 - pos2);

		// 解码邮件正文内容
		string decoded2 = base64_decode(truncated_str2);

		// 输出邮件正文解码后的内容
		CString cstr2(decoded2.c_str());
		pdlg->displayString(pdlg->m_text,cstr2);



		// 附件部分：
		// 如果有文本或图片类型的附件
		//（文本型仅支持 txt 类型文件（ANSI 编码））
		//（图片型仅支持 bmp/gif/png/jpg 等类型的文件）
		// 若同名文件，则仅接收第一个文件（map 容器的限制）

		// 先获取附件的名称和编码
		map<string, string>attachment;
		while (pos2 != s.npos) 
		{
			// 获取附件的名称
			pos2 = s.find("Content-Disposition: attachment;\r\n\tfilename=\"",pos2);
			if (pos2 == s.npos)
				break;
			pos3 = s.find("\"\r\n\r\n", pos2);
			temp = "Content-Disposition: attachment;\r\n\tfilename=\"";
			pos2 += temp.length();
			truncated_str2 = s.substr(pos2, pos3 - pos2);
			string attachmentName = truncated_str2;

			// 获取附件的 base64 编码
			temp = "\"\r\n\r\n";
			pos3 += temp.length();
			size_t pos4= s.find("\r\n\r\n", pos3);
			truncated_str2 = s.substr(pos3, pos4 - pos3);
			string attachmentEncode = truncated_str2;

			// 将得到的名称-编码对加入 map 映射
			attachment.insert(pair<string, string>(attachmentName, attachmentEncode));

			// 输出附件列表，键重复的只会列出第一个（不支持同名文件传入）
			CString cstr1(attachmentName.c_str());
			pdlg->displayString(pdlg->m_attachmentName, cstr1 + _T("\r\n"));
		}

		// 处理附件 map 映射中的数据
		while (!attachment.empty())
		{
			string attachmentName = attachment.begin()->first;
			string attachmentEncode = attachment.begin()->second;

			// 检测文件后缀名
			size_t pos5 = attachmentName.find(".");
			string sub = attachmentName.substr(pos5 + 1, attachmentName.npos);
			if (sub == "txt")
			{
				// 解码文本型附件内容（仅支持编码为 ANSI 的文本型附件）
				string decoded2 = base64_decode(attachmentEncode);

				// 输出文本型附件解码后的内容
				decoded2 = attachmentName + " 的内容如下：\r\n————————————————\r\n\r\n" + decoded2;
				CString cstr2(decoded2.c_str());
				pdlg->displayString(pdlg->m_attachmentText, cstr2);
			}
			else
			{
				// 读取图片  
				// 把编码的字符串输入文件，返回值为图片文件名
				CString FileName = base64_decode_picture(attachmentName, attachmentEncode);

				//HBITMAP hBmp = (HBITMAP)::LoadImage(
				//	AfxGetInstanceHandle(), FileName, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);  // 将位图加载到 hBmp  
				//pdlg->m_picture.SetBitmap(hBmp);

				// CImage provides enhanced bitmap support, including the ability to load and save 
				// images in JPEG, GIF, BMP, and Portable Network Graphics (PNG) formats.
				CImage image;
				HBITMAP hBmp;
				image.Load(FileName);
				hBmp = image.Detach();
				// 让图片控件显示位图
				// pdlg->m_picture.SetBitmap(NULL);
				pdlg->m_picture.SetBitmap(hBmp);

				pdlg->UpdateData();
				pdlg->Invalidate();
				pdlg->UpdateWindow();

				// 将图片加入图片列表里，交给 Picture 按钮用默认程序打开图片
				// 如果需要打开多张图，必须在收信前按下 Picture 按钮
				imageList.push(FileName);
			}

			attachment.erase(attachmentName);
		}

		// 用默认程序打开图片
		if (pdlg->openPictures)
		{
			while (!imageList.empty())
			{
				CString imageName = imageList.front();
				ShellExecute(nullptr, _T("open"), imageName, _T(""), _T(""), SW_SHOW);
				imageList.pop();
			}
		}


		// 传输数据终止
		data = false;
		// 投递一个“读“的事件，准备接收
		AsyncSelect(FD_READ);
	}
	if (buffer[revLength-3] == '.')
	{
		pdlg->m_log.InsertString(-1, (L"C: " + str));
		char reply[100] = "250 OK\r\n";
		Send(reply, strlen(reply), 0);
		AsyncSelect(FD_READ);
		pdlg->m_log.InsertString(-1, (L"S: 250 OK\r\n"));
	}
	if (str.Left(4) == "QUIT")
	{
		pdlg->m_log.InsertString(-1, (L"C: " + str));
		char reply[100] = "221\r\n";
		Send(reply, strlen(reply), 0);
		AsyncSelect(FD_READ);
		pdlg->m_log.InsertString(-1, (L"S: 221"));
	}


	// 刷新对话框界面
	pdlg->UpdateData();
	pdlg->Invalidate();
	pdlg->UpdateWindow();
	CAsyncSocket::OnReceive(nErrorCode);
}