﻿#pragma once

#include "string"
#include <map>
#include "queue"
#include<atlimage.h>

using namespace std;

// ServerSocket 命令目标

class ServerSocket : public CAsyncSocket
{
public:
	ServerSocket();
	virtual ~ServerSocket();
	void CheckSymbol(char& c); // 将 base64 编码后的字符解码。
	CString base64_decode_picture(string attachmentName,string encoded_string); // base64 图片解码
	string base64_decode(string encoded_string); // base64 解码
	virtual void OnReceive(int nErrorCode);
	bool data = false; // 判断是否在传输数据的标志 0->否 1->是
	map<char, int> base64_map; // base64 解码表
	queue<CString> imageList; // 存储要打开的图片
};


