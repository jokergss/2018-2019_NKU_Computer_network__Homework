﻿
// SMTPDlg.h: 头文件
//

#pragma once
#include "ListenServer.h"


// CSMTPDlg 对话框
class CSMTPDlg : public CDialogEx
{
// 构造
public:
	CSMTPDlg(CWnd* pParent = nullptr);	// 标准构造函数

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_SMTP_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV 支持


// 实现
protected:
	HICON m_hIcon;

	// 生成的消息映射函数
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	// 显示函数（一个能在编辑框里显示文本的万能函数）
	void displayString(CEdit& editCtrl, CString& str);
	// 附件名
	CEdit m_attachmentName;
	// 日志
	CListBox m_log;
	// 邮件报文
	// CEditCtrl m_messege;
	// 附件图片
	CStatic m_picture;
	// TCP 侦听 socket
	ListenServer listen;
	afx_msg void OnBnClickedStart();
	afx_msg void OnBnClickedClear();
	// 判断是否开始监听
	bool isListen = false;
	// 清除所有输出
	CButton m_clear;
	// 开始/关闭服务器
	CButton m_start;
	// 邮件报文
	CEdit m_message;
	// Mail Text
	CEdit m_text;
	// 如果附件中有文本文件，则在这里显示
	CEdit m_attachmentText;
	// 打开图片按钮，如果需要打开多张图，必须在收信前按下此按钮
	CButton m_pictureButton;
	// 是否需要打开图片的 flag
	bool openPictures = false;
	afx_msg void OnBnClickedButtonpicture();
};
