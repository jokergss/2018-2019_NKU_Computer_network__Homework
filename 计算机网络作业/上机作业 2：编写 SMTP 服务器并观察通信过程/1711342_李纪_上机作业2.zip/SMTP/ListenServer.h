﻿#pragma once
#include <list>

// ListenServer 命令目标
#include "ServerSocket.h"

class ListenServer : public CAsyncSocket
{
public:
	ListenServer();
	virtual ~ListenServer();
	virtual void OnAccept(int nErrorCode);
	virtual void OnClose(int nErrorCode);

	list<ServerSocket*> socketPtrList; // 多用户，多进程维护列表
};


