﻿// ServerUDP.cpp: 实现文件
//

#include "pch.h"
#include "ReRe-Server.h"
#include "ServerUDP.h"
#include "ReRe-ServerDlg.h"


// ServerUDP

ServerUDP::ServerUDP()
{
}

ServerUDP::~ServerUDP()
{
}


// ServerUDP 成员函数


void ServerUDP::OnSend(int nErrorCode)
{
	// TODO: 在此添加专用代码和/或调用基类

	if (nErrorCode)
	{
		AfxMessageBox(_T("Error occurred"));
		return;
	}

	//CAsyncSocket::OnSend(nErrorCode);
}


int ServerUDP::reply(CString req, CString& ret)
{
	// 将接收到的请求一律转为小写
	req = req.MakeLower();
	// date 请求的实现
	if (req == _T("date"))
	{
		//获取当前时间日期  
		CTime m_time = CTime::GetCurrentTime();
		//格式化时间 
		ret = m_time.Format(_T("%x"));
		return 1;
	}
	// time 请求的实现
	if (req == _T("time"))
	{
		//获取当前时间日期  
		CTime m_time = CTime::GetCurrentTime();
		//格式化时间 
		ret = m_time.Format(_T("%X"));
		return 2;
	}
	// file [路径] 请求的实现
	if (req.Left(5) == _T("file "))
	{
		CString csFullPath = req.Mid(5);
		ret = _T("");
		CFileFind find;
		// 获取文件目录
		BOOL IsFind = find.FindFile(csFullPath + _T("/*"));
		while (IsFind)
		{
			IsFind = find.FindNextFile();
			if (find.IsDots()) {
				continue;
			}
			else {
				ret += (find.GetFileName() + _T("\r\n"));
			}
		}
		return 3;
	}
	// who are u 请求的实现
	if (req == _T("who are u"))
	{
		char hostname[40];
		// 获取主机名
		gethostname(hostname, sizeof(hostname));
		ret = (CString)hostname + _T("\r\n");
		return 4;
	}
	return 0;
}


void ServerUDP::OnReceive(int nErrorCode)
{
	// A buffer for the incoming data.
	char m_szBuffer[4096];
	// What ReceiveFrom Returns.
	int nRead;
	CString host, strp;
	UINT port;
	// 获取接收信息
	nRead = ReceiveFrom(m_szBuffer, sizeof(m_szBuffer), host, port,0);
	
	// 按 ReceiveFrom 的返回值来判断如何继续
	switch (nRead)
	{
	// 如果未发生错误， ReceiveFrom() 则返回已接收的字节数。 
	// 如果连接已关闭，则返回0。 
	// 否则，将返回值 SOCKET_ERROR，并通过调用 GetLastError() 来检索特定的错误代码。
	case 0:
		// this->Close();
		break;
	case SOCKET_ERROR:
		AfxMessageBox(_T("Error occurred"));
		Close();
	default:
		// terminate the string
		m_szBuffer[nRead] = _T('\0'); 
		CString strTextOut = (CString)m_szBuffer;
		strp.Format(_T("%d"), port);

		// display the datetime
		// 获取当前时间日期  (用于服务器日志的显示)
		CTime m_time = CTime::GetCurrentTime(); 

		CReReServerDlg* pdlg = (CReReServerDlg*)AfxGetMainWnd();

		// 显示服务器日志
		pdlg->displayString(m_time.Format("%x %X") + _T("\r\n"));
		pdlg->displayString(_T("Receive message[") + strTextOut + _T("] from ") + host + _T(" in port ") + strp + _T(".\r\n"));
		pdlg->displayString(_T("Send message:\r\n"));
		CString response = _T("");

		// 调用 reply 函数
		if (!reply(strTextOut, response))
		{
			// 请求不支持，回复错误请求
			response = _T("Wrong cmd.");
		}
		pdlg->displayString(response + _T("\r\n"));
		char retchar[4096];

		// WideChar 占用空间太大，将其转换为占用较小空间的 Multibyte
		int len = WideCharToMultiByte(CP_ACP, 0, response, -1, NULL, 0, NULL, NULL);
		WideCharToMultiByte(CP_ACP, 0, response, -1, retchar, len, NULL, NULL);

		// 发送请求回复
		SendTo(retchar, strlen(retchar), port, host, 0);
	}

	CAsyncSocket::OnReceive(nErrorCode);
}
