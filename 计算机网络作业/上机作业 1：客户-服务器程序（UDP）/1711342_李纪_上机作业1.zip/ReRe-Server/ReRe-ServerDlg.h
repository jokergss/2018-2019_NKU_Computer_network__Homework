﻿
// ReRe-ServerDlg.h: 头文件
//

#pragma once
#include "ServerUDP.h"
#define UDP 0
#define TCP 1


// CReReServerDlg 对话框
class CReReServerDlg : public CDialogEx
{
// 构造
public:
	// UDP Socket 开启状态
	bool isListen = false;
	// protocolType = 0 -> UDP
	// protocolType = 1 -> TCP
	bool protocolType = UDP;
	ServerUDP usock;

	void displayString(CString str);
	CReReServerDlg(CWnd* pParent = nullptr);	// 标准构造函数

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_RERESERVER_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV 支持


// 实现
protected:
	HICON m_hIcon;

	// 生成的消息映射函数
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	// 监听端口号，默认为 9630
	CEdit portText;
	// 日志控件
	CEdit logText;
	CButton clearButton;
	CButton startButton;
	afx_msg void OnBnClickedClear();
	afx_msg void OnBnClickedStart();
	afx_msg void OnBnClickedUdp();
	afx_msg void OnBnClickedTcp();
	CButton protocolRadio;
};
