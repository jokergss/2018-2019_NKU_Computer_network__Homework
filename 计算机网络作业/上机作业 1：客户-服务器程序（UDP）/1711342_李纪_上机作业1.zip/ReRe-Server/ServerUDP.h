﻿#pragma once
#include "afxsock.h"  
// ServerUDP 命令目标

class ServerUDP : public CAsyncSocket
{
public:
	ServerUDP();
	virtual ~ServerUDP();
	// 发送回复信息
	virtual void OnSend(int nErrorCode);
	// 构造回复信息
	int reply(CString req, CString& ret);
	virtual void OnReceive(int nErrorCode);
};


